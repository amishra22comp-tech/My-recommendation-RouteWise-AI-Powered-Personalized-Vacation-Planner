"""Parse a natural-language trip request into structured constraints."""
import re

WORD_NUMS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}


def parse_request(text: str, default_days=3, default_budget=20000):
    t = text.lower()
    for w, n in WORD_NUMS.items():
        t = re.sub(rf"\b{w}\b(?=[\s-]*days?)", str(n), t)

    days = default_days
    m = re.search(r"(\d+)[\s-]*days?", t)
    if m:
        days = max(1, min(int(m.group(1)), 10))

    budget = default_budget
    m = re.search(r"(?:under|below|within|budget(?:\s+of)?|upto|up to|₹|rs\.?|inr)\s*₹?\s*([\d,]+(?:\.\d+)?)\s*(k|thousand|lakh|l)?\b", t)
    if m:
        budget = float(m.group(1).replace(",", ""))
        unit = m.group(2)
        if unit in ("k", "thousand"):
            budget *= 1_000
        elif unit in ("lakh", "l"):
            budget *= 100_000

    interests = re.sub(r"(\d+[\s-]*days?)|(?:under|below|within|budget(?:\s+of)?|upto|up to|₹|rs\.?|inr)\s*₹?\s*[\d,.]+\s*(k|thousand|lakh|l)?\b", " ", t)
    interests = re.sub(r"\b(i|love|like|want|to|a|an|the|in|for|trip|plan|me|my|and|with)\b", " ", interests)
    interests = re.sub(r"\s+", " ", interests).strip()
    return {"days": days, "budget": budget, "interests": interests}
