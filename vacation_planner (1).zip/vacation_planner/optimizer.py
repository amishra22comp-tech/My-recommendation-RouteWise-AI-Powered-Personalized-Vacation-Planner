"""Itinerary optimizer: constrained selection, geographic day clustering,
route ordering (nearest neighbour + 2-opt) and opening-hour aware scheduling."""
import math

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

SPEED_KMH = 30.0       # average road speed incl. traffic
DAY_START = 9.0        # 9:00
DAY_END = 21.0         # 21:00
HOURS_PER_DAY = 9.0    # activity + travel budget per day


def haversine_km(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    d = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371 * 2 * math.asin(math.sqrt(d))


def travel_h(a, b):
    return haversine_km(a, b) / SPEED_KMH


def select_attractions(ranked: pd.DataFrame, days: int, budget: float, min_score: float = 0.05):
    """Greedy knapsack by score: respect total budget and total time capacity."""
    chosen, spent, hours = [], 0.0, 0.0
    capacity = days * HOURS_PER_DAY * 0.8  # keep 20% slack for travel
    for _, row in ranked.iterrows():
        if row["score"] < min_score:
            continue
        if spent + row["cost"] > budget or hours + row["duration_h"] > capacity:
            continue
        chosen.append(row)
        spent += row["cost"]
        hours += row["duration_h"]
    return pd.DataFrame(chosen).reset_index(drop=True)


def _route_length(order, coords):
    return sum(haversine_km(coords[order[i]], coords[order[i + 1]]) for i in range(len(order) - 1))


def order_route(coords):
    """Nearest neighbour start, then 2-opt improvement. Returns index order."""
    n = len(coords)
    if n <= 2:
        return list(range(n))
    remaining = set(range(1, n))
    order = [0]
    while remaining:
        nxt = min(remaining, key=lambda j: haversine_km(coords[order[-1]], coords[j]))
        order.append(nxt)
        remaining.remove(nxt)
    improved = True
    while improved:
        improved = False
        for i in range(1, n - 1):
            for j in range(i + 1, n):
                new = order[:i] + order[i:j + 1][::-1] + order[j + 1:]
                if _route_length(new, coords) + 1e-9 < _route_length(order, coords):
                    order, improved = new, True
    return order


def schedule_day(stops: pd.DataFrame):
    """Walk the stops in order, adding travel time and waiting for opening.
    Stops that cannot be finished before closing / day end are dropped."""
    t, prev = DAY_START, None
    visits, dropped = [], []
    for _, s in stops.iterrows():
        if prev is not None:
            t += travel_h((prev["lat"], prev["lon"]), (s["lat"], s["lon"]))
        arrive = max(t, s["open"])
        leave = arrive + s["duration_h"]
        if leave > min(s["close"], DAY_END):
            dropped.append(s["name"])
            continue
        visits.append({**s.to_dict(), "arrive": arrive, "leave": leave})
        t, prev = leave, s
    return visits, dropped


def _day_travel_h(visits):
    return sum(
        travel_h((visits[i]["lat"], visits[i]["lon"]), (visits[i + 1]["lat"], visits[i + 1]["lon"]))
        for i in range(len(visits) - 1)
    )


def _summarise(days_visits, dropped):
    flat = [v for d in days_visits for v in d]
    return {
        "days": days_visits,
        "dropped": dropped,
        "travel_h": sum(_day_travel_h(d) for d in days_visits),
        "cost": sum(v["cost"] for v in flat),
        "n_stops": len(flat),
        "score": sum(v["score"] for v in flat),
    }


def optimize_itinerary(selected: pd.DataFrame, days: int):
    """Cluster by location into days, order each day with 2-opt, then schedule."""
    if selected.empty:
        return _summarise([[] for _ in range(days)], [])
    k = min(days, len(selected))
    coords = selected[["lat", "lon"]].to_numpy()
    labels = KMeans(n_clusters=k, n_init=10, random_state=0).fit_predict(coords) if k > 1 else np.zeros(len(selected), int)
    days_visits, dropped = [], []
    for d in range(k):
        grp = selected[labels == d].reset_index(drop=True)
        c = list(zip(grp["lat"], grp["lon"]))
        grp = grp.iloc[order_route(c)].reset_index(drop=True)
        visits, drop = schedule_day(grp)
        days_visits.append(visits)
        dropped += drop
    days_visits += [[] for _ in range(days - len(days_visits))]

    # Repair step: try to re-insert dropped stops into whichever day fits them
    # with the least extra travel, re-optimizing that day's route each time.
    by_name = selected.set_index("name", drop=False)
    still_dropped = []
    for name in dropped:
        stop = by_name.loc[name]
        best = None
        for d, day in enumerate(days_visits):
            grp = pd.DataFrame([{k: v for k, v in s.items() if k not in ("arrive", "leave")} for s in day] + [stop.to_dict()])
            grp = grp.iloc[order_route(list(zip(grp["lat"], grp["lon"])))].reset_index(drop=True)
            visits, drop = schedule_day(grp)
            if drop:
                continue
            extra = _day_travel_h(visits) - _day_travel_h(day)
            if best is None or extra < best[0]:
                best = (extra, d, visits)
        if best:
            days_visits[best[1]] = best[2]
        else:
            still_dropped.append(name)
    return _summarise(days_visits, still_dropped)


def baseline_itinerary(selected: pd.DataFrame, days: int):
    """Naive plan: same places, visited in preference-score order, filled day by day
    (what a plain 'list the best things' LLM answer looks like)."""
    per_day = max(1, math.ceil(len(selected) / days))
    days_visits, dropped = [], []
    for d in range(days):
        grp = selected.iloc[d * per_day:(d + 1) * per_day].reset_index(drop=True)
        visits, drop = schedule_day(grp)
        days_visits.append(visits)
        dropped += drop
    return _summarise(days_visits, dropped)
