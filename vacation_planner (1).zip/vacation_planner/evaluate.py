"""Evaluate optimized itineraries against a naive baseline on several scenarios.
Run with:  python evaluate.py
"""
import pandas as pd

from optimizer import baseline_itinerary, optimize_itinerary, select_attractions
from recommender import load_attractions, rank_attractions
from request_parser import parse_request

SCENARIOS = [
    "3 days in Goa under 10k, I love beaches and nightlife",
    "5 days in Goa under 30k, I love food and quiet places",
    "4 days in Goa under 15000 history forts and heritage",
    "2 days in Goa budget 8k adventure and nature",
    "6 days in Goa under 40k culture shopping and food",
    "3 days in Goa under 12k relaxing scenic sunset",
    "4 days in Goa under 20k beach adventure watersports",
    "5 days in Goa under 25k heritage temple quiet nature",
]


def main():
    df = load_attractions()
    rows = []
    for text in SCENARIOS:
        req = parse_request(text)
        ranked, _ = rank_attractions(df, req["interests"], use_embeddings=False)
        sel = select_attractions(ranked, req["days"], req["budget"])
        opt = optimize_itinerary(sel, req["days"])
        base = baseline_itinerary(sel, req["days"])
        rows.append({
            "scenario": text,
            "baseline_travel_h": round(base["travel_h"], 2),
            "optimized_travel_h": round(opt["travel_h"], 2),
            "travel_saved_%": round((1 - opt["travel_h"] / base["travel_h"]) * 100, 1) if base["travel_h"] else 0.0,
            "base_h_per_stop": round(base["travel_h"] / max(base["n_stops"], 1), 2),
            "opt_h_per_stop": round(opt["travel_h"] / max(opt["n_stops"], 1), 2),
            "baseline_stops": base["n_stops"],
            "optimized_stops": opt["n_stops"],
            "within_budget": opt["cost"] <= req["budget"],
        })
    res = pd.DataFrame(rows)
    pd.set_option("display.width", 200, "display.max_colwidth", 55)
    print(res.to_string(index=False))
    print(f"\nAverage travel time saved: {res['travel_saved_%'].mean():.1f}%")
    print(f"Budget respected in {res['within_budget'].mean() * 100:.0f}% of scenarios")
    print(f"Average extra stops completed: {(res['optimized_stops'] - res['baseline_stops']).mean():.2f}")
    res.to_csv("evaluation_results.csv", index=False)


if __name__ == "__main__":
    main()
