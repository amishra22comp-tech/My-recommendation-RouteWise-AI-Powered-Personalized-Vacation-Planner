# AI Vacation Planner

Personalized trip planner that combines a **preference-based recommender** (sentence-transformer embeddings, with a TF-IDF fallback) and a **constraint-aware route optimizer** (budget, time, opening hours, geographic clustering, nearest-neighbour + 2-opt routing). A Streamlit UI shows the itinerary, a map, and a comparison against a naive plan.

## Run in VS Code

1. Install **Python 3.10+** and the **Python** extension in VS Code.
2. `File > Open Folder...` and choose this `vacation_planner` folder.
3. Open a terminal (`Ctrl + `` ` ``) and create a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. `pip install -r requirements.txt`
5. Press `Ctrl+Shift+P`, choose **Python: Select Interpreter**, and pick the `.venv` one.
6. Run the app: `streamlit run app.py`, or press `F5` and choose **Streamlit: run app**.
7. Run the evaluation: `python evaluate.py`, or `F5` and choose **Python: evaluate.py**.

> On Windows, if the interpreter path in `.vscode/settings.json` is wrong, change it to `${workspaceFolder}\\.venv\\Scripts\\python.exe`.

## How it works

| Step | File | What happens |
|---|---|---|
| 1 | `request_parser.py` | Pulls days, budget and interests from text like "5 days in Goa under 30k, I love food and quiet places" |
| 2 | `recommender.py` | Scores every attraction against the interests (embeddings or TF-IDF) |
| 3 | `optimizer.py` | Picks attractions within budget and time, clusters them into days by location, orders each day's route with 2-opt, schedules around opening hours, and re-inserts dropped stops |
| 4 | `app.py` | Streamlit UI with itinerary tables, map and baseline comparison |
| 5 | `evaluate.py` | Compares optimized vs naive itineraries on 8 scenarios |

## Evaluation (TF-IDF mode, 8 scenarios)

- Average travel time reduced by about **57%** versus a naive score-ordered plan
- About **1.25 more stops** completed per trip
- Budget respected in **100%** of scenarios

Re-run `python evaluate.py` to reproduce; results are saved to `evaluation_results.csv`.

## Extending it

- Replace `data/attractions.csv` with data from Google Places or OpenTripMap to cover more cities.
- Use real road distances (OpenRouteService or Google Distance Matrix) instead of straight-line distance.
- Add weather (OpenWeather) so outdoor stops move to dry days.
- Add an LLM call to parse requests and write friendly itinerary descriptions.
- Store saved trips with Supabase and deploy on Streamlit Cloud or AWS.

## Limitations

The dataset is a small hand-built Goa sample (20 places), distances are straight-line estimates at 30 km/h, and costs are approximate. Treat the evaluation numbers as a prototype benchmark, not a real-world result.
