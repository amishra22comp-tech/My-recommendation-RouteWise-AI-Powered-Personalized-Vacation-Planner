"""Streamlit UI. Run with:  streamlit run app.py"""
import pandas as pd
import streamlit as st

from optimizer import baseline_itinerary, optimize_itinerary, select_attractions
from recommender import load_attractions, rank_attractions
from request_parser import parse_request

st.set_page_config(page_title="AI Vacation Planner", page_icon="🧭", layout="wide")
st.title("🧭 AI Vacation Planner")
st.caption("Recommendation (embeddings / TF-IDF) + budget & time-constrained route optimization")


def hhmm(h):
    return f"{int(h):02d}:{int(round((h % 1) * 60)):02d}"


text = st.text_input(
    "Describe your trip",
    "5 days in Goa under 30k, I love food and quiet places",
)
with st.sidebar:
    st.header("Settings")
    use_emb = st.checkbox("Use sentence-transformers (if installed)", value=False)
    compare = st.checkbox("Compare with naive baseline", value=True)

if st.button("Plan my trip", type="primary"):
    req = parse_request(text)
    df = load_attractions()
    ranked, method = rank_attractions(df, req["interests"], use_embeddings=use_emb)
    selected = select_attractions(ranked, req["days"], req["budget"])
    plan = optimize_itinerary(selected, req["days"])

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Days", req["days"])
    c2.metric("Budget (₹)", f"{req['budget']:,.0f}")
    c3.metric("Planned cost (₹)", f"{plan['cost']:,.0f}")
    c4.metric("Travel time (h)", f"{plan['travel_h']:.1f}")
    st.caption(f"Interests understood as: **{req['interests'] or 'general sightseeing'}** · ranking method: {method}")

    map_rows = []
    for i, day in enumerate(plan["days"], 1):
        st.subheader(f"Day {i}")
        if not day:
            st.write("Free day.")
            continue
        rows = [
            {"Time": f"{hhmm(v['arrive'])}-{hhmm(v['leave'])}", "Place": v["name"],
             "Category": v["category"], "Cost (₹)": v["cost"], "Match": round(v["score"], 2)}
            for v in day
        ]
        st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
        map_rows += [{"lat": v["lat"], "lon": v["lon"]} for v in day]

    if map_rows:
        st.subheader("Map")
        st.map(pd.DataFrame(map_rows))
    if plan["dropped"]:
        st.info("Dropped (could not fit opening hours): " + ", ".join(plan["dropped"]))

    if compare:
        base = baseline_itinerary(selected, req["days"])
        st.subheader("Optimized vs naive")
        saved = (1 - plan["travel_h"] / base["travel_h"]) * 100 if base["travel_h"] else 0
        st.table(pd.DataFrame({
            "": ["Travel time (h)", "Stops visited", "Cost (₹)"],
            "Naive (score order)": [f"{base['travel_h']:.1f}", base["n_stops"], f"{base['cost']:,.0f}"],
            "Optimized": [f"{plan['travel_h']:.1f}", plan["n_stops"], f"{plan['cost']:,.0f}"],
        }))
        st.success(f"Travel time reduced by {saved:.0f}%")
