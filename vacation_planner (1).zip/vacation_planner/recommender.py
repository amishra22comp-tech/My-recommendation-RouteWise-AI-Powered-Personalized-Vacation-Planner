"""Preference-based recommender: ranks attractions against free-text interests.

Uses sentence-transformers embeddings when available, otherwise falls back to
TF-IDF cosine similarity, so the project always runs.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_PATH = Path(__file__).parent / "data" / "attractions.csv"


def load_attractions(path=DATA_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["text"] = df["category"] + " " + df["tags"] + " " + df["description"]
    return df


def _embedding_scores(texts, query):
    from sentence_transformers import SentenceTransformer  # optional dependency

    model = SentenceTransformer("all-MiniLM-L6-v2")
    doc_vecs = model.encode(texts, normalize_embeddings=True)
    q_vec = model.encode([query], normalize_embeddings=True)
    return (doc_vecs @ q_vec.T).ravel(), "sentence-transformers"


def _tfidf_scores(texts, query):
    vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    mat = vec.fit_transform(list(texts) + [query])
    return cosine_similarity(mat[-1], mat[:-1]).ravel(), "tfidf"


def rank_attractions(df: pd.DataFrame, interests: str, use_embeddings: bool = True):
    """Return (df with a 0-1 'score' column sorted best first, method name)."""
    query = interests.strip() or "popular sightseeing"
    scores, method = None, None
    if use_embeddings:
        try:
            scores, method = _embedding_scores(df["text"].tolist(), query)
        except Exception:
            scores = None
    if scores is None:
        scores, method = _tfidf_scores(df["text"].tolist(), query)

    out = df.copy()
    lo, hi = scores.min(), scores.max()
    out["score"] = (scores - lo) / (hi - lo) if hi > lo else np.zeros_like(scores)
    return out.sort_values("score", ascending=False).reset_index(drop=True), method
